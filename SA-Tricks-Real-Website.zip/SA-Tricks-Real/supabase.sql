-- SA Tricks Supabase setup
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'user' check (role in ('user','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.apps (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  version text not null,
  image_url text,
  apk_path text not null,
  downloads text default '0',
  rating text default '5.0',
  popular boolean not null default false,
  published boolean not null default true,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin'
  );
$$;

alter table public.profiles enable row level security;
alter table public.apps enable row level security;

drop policy if exists "profiles own read" on public.profiles;
create policy "profiles own read" on public.profiles
for select to authenticated using (id = auth.uid() or public.is_admin());

drop policy if exists "public published apps read" on public.apps;
create policy "public published apps read" on public.apps
for select to anon, authenticated using (published = true);

drop policy if exists "admin manage apps" on public.apps;
create policy "admin manage apps" on public.apps
for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- Storage buckets. Run these in SQL Editor; if a bucket already exists,
-- the DO blocks leave it unchanged.
insert into storage.buckets (id, name, public)
values ('app-images','app-images',true)
on conflict (id) do update set public = true;

insert into storage.buckets (id, name, public)
values ('app-files','app-files',true)
on conflict (id) do update set public = true;

drop policy if exists "public read app images" on storage.objects;
create policy "public read app images" on storage.objects
for select to anon, authenticated
using (bucket_id = 'app-images');

drop policy if exists "admin upload app images" on storage.objects;
create policy "admin upload app images" on storage.objects
for insert to authenticated
with check (bucket_id = 'app-images' and public.is_admin());

drop policy if exists "admin update app images" on storage.objects;
create policy "admin update app images" on storage.objects
for update to authenticated
using (bucket_id = 'app-images' and public.is_admin())
with check (bucket_id = 'app-images' and public.is_admin());

drop policy if exists "admin delete app images" on storage.objects;
create policy "admin delete app images" on storage.objects
for delete to authenticated
using (bucket_id = 'app-images' and public.is_admin());

drop policy if exists "public read app files" on storage.objects;
create policy "public read app files" on storage.objects
for select to anon, authenticated
using (bucket_id = 'app-files');

drop policy if exists "admin upload app files" on storage.objects;
create policy "admin upload app files" on storage.objects
for insert to authenticated
with check (bucket_id = 'app-files' and public.is_admin());

drop policy if exists "admin update app files" on storage.objects;
create policy "admin update app files" on storage.objects
for update to authenticated
using (bucket_id = 'app-files' and public.is_admin())
with check (bucket_id = 'app-files' and public.is_admin());

drop policy if exists "admin delete app files" on storage.objects;
create policy "admin delete app files" on storage.objects
for delete to authenticated
using (bucket_id = 'app-files' and public.is_admin());
