# SA Tricks — Public Website + Real Admin + APK Upload

This version uses Supabase for the online database, authentication, and file storage.

## Files
- `index.html` — public website
- `admin.html` — real admin login/upload/delete panel
- `style.css` — design
- `script.js` — public site logic
- `admin.js` — admin logic
- `config.js` — Supabase URL/key
- `supabase.sql` — database + Row Level Security + Storage policies
- `logo.png` + app placeholder icons

## Setup
1. Create a Supabase project.
2. Open SQL Editor and run `supabase.sql`.
3. In Authentication, create your admin user (email/password).
4. Copy the admin user's UUID.
5. In SQL Editor run:
   `insert into public.profiles (id, role) values ('YOUR-USER-UUID','admin') on conflict (id) do update set role='admin';`
6. Put your Supabase URL and publishable/anon key into `config.js`.
7. Upload the project files to your static host (or open locally for testing).
8. Open `admin.html`, log in, and upload app icon + APK.
9. Public visitors use `index.html`.

Telegram: https://t.me/satricks09

Important:
- The browser must only use the publishable/anon key, never a service_role/secret key.
- APK storage is public so visitors can download published files.
- Admin upload/delete is protected by database/storage RLS policies.
- For APKs larger than about 6 MB, Supabase recommends resumable/TUS uploads for better reliability; this starter uses the normal browser upload method.
