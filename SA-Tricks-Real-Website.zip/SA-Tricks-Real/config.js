// SA Tricks configuration
// Replace these two values with your Supabase project URL and publishable/anon key.
// Never put a service_role/secret key in browser code.
window.SA_CONFIG = {
  SUPABASE_URL: "https://YOUR-PROJECT.supabase.co",
  SUPABASE_ANON_KEY: "YOUR-PUBLISHABLE-OR-ANON-KEY"
};
